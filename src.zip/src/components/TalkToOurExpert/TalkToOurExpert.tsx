"use client";

import { useState, useRef, useEffect, useMemo, type FormEvent, type ReactNode } from "react";
import Image from "next/image";
import { allCountries } from "country-telephone-data";
import "./TalkToOurExpert.css";

interface RawCountry {
  name: string;
  iso2: string;
  dialCode: string;
}

interface TalkToOurExpertProps {
  isOpen: boolean;
  onClose: () => void;
  onPlayClick?: () => void;
}

interface FormState {
  fullName: string;
  email: string;
  countryIso2: string;
  phoneNumber: string;
  interest: string;
  query: string;
  consent: boolean;
}

interface TouchedState {
  fullName: boolean;
  email: boolean;
  phoneNumber: boolean;
  interest: boolean;
  consent: boolean;
}

const INTEREST_OPTIONS = ["LXP", "Content Management", "Course Management", "Assessments @ Analytics", "Interactive Learning", "Gamification", "Corporate L&D", "Higher Education", "Geenral  Enquiry", "Custom Requirement", "Other"];

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_PATTERN = /^[0-9]{7,15}$/;

const COUNTRIES = (allCountries as unknown as RawCountry[]).filter((country, index, list) => list.findIndex((entry) => entry.iso2 === country.iso2) === index);

function getFlagEmoji(iso2: string) {
  return iso2.toUpperCase().replace(/./g, (char) => String.fromCodePoint(127397 + char.charCodeAt(0)));
}

function IconBubble({ children }: { children: ReactNode }) {
  return <span className="tte-icon-bubble">{children}</span>;
}

function UserIcon() {
  return (
    <svg width="21" height="26" viewBox="0 0 21 26" fill="none">
      <g filter="url(#tteUserShadow)">
        <path d="M14.6338 7.09509C14.6356 4.79391 12.7715 2.92696 10.4704 2.92515C8.16919 2.92334 6.30224 4.78736 6.30044 7.08854C6.29863 9.38971 8.16265 11.2567 10.4638 11.2585C12.765 11.2603 14.632 9.39625 14.6338 7.09509Z" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M16.292 17.0964C16.2945 13.8747 13.6849 11.261 10.4632 11.2585C7.24156 11.256 4.62783 13.8656 4.6253 17.0872" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <defs>
        <filter id="tteUserShadow" x="-3.54395" y="0" width="28.0156" height="28.0156" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
          <feFlood floodOpacity="0" result="tteUserBg" />
          <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="tteUserHardAlpha" />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="2" />
          <feComposite in2="tteUserHardAlpha" operator="out" />
          <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
          <feBlend mode="normal" in2="tteUserBg" result="tteUserShadowBlend" />
          <feBlend mode="normal" in="SourceGraphic" in2="tteUserShadowBlend" result="shape" />
        </filter>
      </defs>
    </svg>
  );
}

function MailIcon() {
  return (
    <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
      <g filter="url(#tteMailShadow)">
        <path d="M4.625 5L10.3858 8.26414C12.5097 9.4675 13.407 9.4675 15.5308 8.26414L21.2917 5" stroke="#2F3547" strokeWidth="1.25" strokeLinejoin="round" />
        <path d="M4.63814 11.231C4.69262 13.7856 4.71986 15.0629 5.66247 16.0091C6.60507 16.9553 7.91694 16.9882 10.5407 17.0541C12.1577 17.0948 13.7589 17.0948 15.376 17.0541C17.9997 16.9882 19.3116 16.9553 20.2542 16.0091C21.1968 15.0629 21.2241 13.7856 21.2785 11.231C21.2961 10.4096 21.2961 9.59305 21.2785 8.77164C21.2241 6.21702 21.1968 4.93971 20.2542 3.99352C19.3116 3.04733 17.9997 3.01437 15.376 2.94844C13.7589 2.90781 12.1577 2.90781 10.5407 2.94844C7.91694 3.01435 6.60507 3.04731 5.66246 3.99351C4.71985 4.9397 4.69262 6.21701 4.63813 8.77164C4.62062 9.59305 4.62063 10.4096 4.63814 11.231Z" stroke="#2F3547" strokeWidth="1.25" strokeLinejoin="round" />
      </g>
      <defs>
        <filter id="tteMailShadow" x="-1.04102" y="0" width="28" height="28" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
          <feFlood floodOpacity="0" result="tteMailBg" />
          <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="tteMailHardAlpha" />
          <feOffset dy="4" />
          <feGaussianBlur stdDeviation="2" />
          <feComposite in2="tteMailHardAlpha" operator="out" />
          <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0" />
          <feBlend mode="normal" in2="tteMailBg" result="tteMailShadowBlend" />
          <feBlend mode="normal" in="SourceGraphic" in2="tteMailShadowBlend" result="shape" />
        </filter>
      </defs>
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg width="21" height="21" viewBox="0 0 21 21" fill="none">
      <path d="M7.64387 4.76618L7.30891 4.01093C7.0899 3.51712 6.98039 3.2702 6.81648 3.08118C6.61106 2.84429 6.34319 2.66991 6.04344 2.57794C5.80425 2.50454 5.53414 2.50433 4.99394 2.5039C4.20369 2.50328 3.80856 2.50297 3.47675 2.65462C3.08589 2.83325 2.73273 3.22153 2.59182 3.62751C2.4722 3.97216 2.50611 4.32647 2.57392 5.03508C3.29577 12.5777 7.42744 16.7159 14.9689 17.4496C15.6774 17.5185 16.0317 17.553 16.3765 17.4339C16.7828 17.2936 17.1716 16.9411 17.3509 16.5505C17.503 16.219 17.5033 15.8238 17.5039 15.0335C17.5043 14.4934 17.5045 14.2233 17.4315 13.984C17.34 13.6841 17.1661 13.4159 16.9295 13.2101C16.7408 13.0459 16.494 12.936 16.0005 12.7162L15.2458 12.3801C14.7114 12.1421 14.4442 12.023 14.1726 11.997C13.9126 11.972 13.6505 12.0083 13.4071 12.1029C13.1528 12.2017 12.928 12.3888 12.4782 12.763C12.0305 13.1354 11.8067 13.3216 11.5333 13.4213C11.2909 13.5097 10.9706 13.5422 10.7154 13.5044C10.4275 13.4617 10.2072 13.3437 9.76648 13.1078C8.39539 12.3736 7.63954 11.6166 6.90757 10.2444C6.67231 9.80327 6.55468 9.58276 6.51248 9.29481C6.47507 9.03962 6.50811 8.71931 6.59682 8.47705C6.69688 8.20381 6.88347 7.98027 7.25663 7.53318C7.63151 7.08404 7.81896 6.85947 7.91816 6.60529C8.0131 6.36206 8.04979 6.09997 8.02527 5.84002C7.99964 5.56837 7.88105 5.30097 7.64387 4.76618Z" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" />
    </svg>
  );
}

function ClipboardIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path d="M10 9.16602H13.3333" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M10 13.334H13.3333" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6.66699 9.16602H6.67533" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6.66699 13.334H6.67533" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M12.0837 1.66602H7.91699C7.22663 1.66602 6.66699 2.22566 6.66699 2.91602C6.66699 3.60637 7.22663 4.16602 7.91699 4.16602H12.0837C12.774 4.16602 13.3337 3.60637 13.3337 2.91602C13.3337 2.22566 12.774 1.66602 12.0837 1.66602Z" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M13.333 2.91602C14.6276 2.95502 15.3997 3.09941 15.9341 3.63382C16.6663 4.36605 16.6663 5.54455 16.6663 7.90154V13.3323C16.6663 15.6893 16.6663 16.8678 15.9341 17.6C15.2018 18.3323 14.0233 18.3323 11.6663 18.3323H8.33301C5.97599 18.3323 4.79748 18.3323 4.06525 17.6C3.33302 16.8678 3.33302 15.6893 3.33301 13.3323L3.33302 7.90159C3.33302 5.54456 3.33301 4.36605 4.06524 3.63382C4.59965 3.09941 5.37177 2.95502 6.66626 2.91602" stroke="#2F3547" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ArrowDownIcon({ open }: { open?: boolean }) {
  return (
    <svg width="12" height="7" viewBox="0 0 12 7" fill="none" className={`tte-chevron${open ? " tte-chevron-open" : ""}`}>
      <path d="M10.625 0.625041C10.625 0.625041 6.94258 5.625 5.625 5.625C4.30733 5.625 0.625 0.625 0.625 0.625" stroke="#141B34" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function BotIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
      <path d="M15.167 8.16602H12.8337C9.55659 8.16602 7.91804 8.16602 6.741 8.95249C6.23145 9.29297 5.79395 9.73047 5.45347 10.24C4.66699 11.4171 4.66699 13.0556 4.66699 16.3327C4.66699 19.6097 4.66699 21.2483 5.45347 22.4254C5.79395 22.9348 6.23145 23.3723 6.741 23.7129C7.91804 24.4993 9.55659 24.4994 12.8337 24.4994H15.167C18.444 24.4994 20.0826 24.4993 21.2597 23.7129C21.7692 23.3723 22.2067 22.9348 22.5472 22.4254C23.3337 21.2483 23.3337 19.6097 23.3337 16.3327C23.3337 13.0556 23.3337 11.4171 22.5472 10.24C22.2067 9.73047 21.7692 9.29297 21.2597 8.95249C20.0826 8.16602 18.444 8.16602 15.167 8.16602Z" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M4.66634 16.334H2.33301" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M11.667 19.834H16.3337" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M25.6663 16.334H23.333" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M17.5 12.834V15.1673" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M10.5 12.834V15.1673" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M13.9997 8.16667C13.9997 5.96678 13.9997 4.86683 13.3162 4.18342C12.6328 3.5 11.5329 3.5 9.33301 3.5" stroke="#2D4CC8" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ResizeIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path d="M20 4L4 20M20 11L11 20M20 18L18 20" stroke="#2F3547" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function RadioCheckedIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="7.3" fill="#2D4CC8" stroke="#2D4CC8" strokeWidth="1.5" />
      <path d="M5.3 8.2L7.1 10L10.7 6.2" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function RadioEmptyIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6.7" stroke="rgba(49, 52, 75, 0.2)" strokeWidth="1.5" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
      <path d="M6 6L18 18M18 6L6 18" stroke="#31344B" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg width="40" height="45" viewBox="0 0 40 45" fill="none" aria-hidden="true" focusable="false">
      <path d="M38 20.6699C39.3333 21.4408 39.3333 23.3743 38 24.1453L4.25 43.6367C2.91667 44.4077 1.25 43.4409 1.25 41.899L1.25 2.91616C1.25 1.37429 2.91667 0.407462 4.25 1.17839L38 20.6699Z" stroke="#FFFFFF" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

export default function TalkToOurExpert({ isOpen, onClose, onPlayClick }: TalkToOurExpertProps) {
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const previousActiveElement = useRef<HTMLElement | null>(null);
  const countryDropdownRef = useRef<HTMLDivElement | null>(null);
  const interestDropdownRef = useRef<HTMLDivElement | null>(null);

  const [formData, setFormData] = useState<FormState>({
    fullName: "",
    email: "",
    countryIso2: "in",
    phoneNumber: "",
    interest: "LXP",
    query: "",
    consent: false,
  });
  const [touched, setTouched] = useState<TouchedState>({
    fullName: false,
    email: false,
    phoneNumber: false,
    interest: false,
    consent: false,
  });
  const [countrySearch, setCountrySearch] = useState("");
  const [isCountryOpen, setIsCountryOpen] = useState(false);
  const [isInterestOpen, setIsInterestOpen] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setFormData({
        fullName: "",
        email: "",
        countryIso2: "in",
        phoneNumber: "",
        interest: "LXP",
        query: "",
        consent: false,
      });
      setTouched({ fullName: false, email: false, phoneNumber: false, interest: false, consent: false });
      setSubmitted(false);
      setCountrySearch("");
      setIsCountryOpen(false);
      setIsInterestOpen(false);
      return;
    }

    previousActiveElement.current = document.activeElement as HTMLElement | null;
    dialogRef.current?.focus();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    document.body.classList.add("modal-open");

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = previousOverflow;
      document.body.classList.remove("modal-open");
      previousActiveElement.current?.focus();
    };
  }, [isOpen, onClose]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (countryDropdownRef.current && !countryDropdownRef.current.contains(event.target as Node)) {
        setIsCountryOpen(false);
      }
      if (interestDropdownRef.current && !interestDropdownRef.current.contains(event.target as Node)) {
        setIsInterestOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selectedCountry = useMemo(() => COUNTRIES.find((country) => country.iso2 === formData.countryIso2) ?? COUNTRIES[0], [formData.countryIso2]);

  const filteredCountries = useMemo(() => {
    const query = countrySearch.trim().toLowerCase();
    if (!query) return COUNTRIES;
    return COUNTRIES.filter((country) => country.name.toLowerCase().includes(query) || country.dialCode.includes(query) || country.iso2.toLowerCase().includes(query));
  }, [countrySearch]);

  const errors = useMemo(
    () => ({
      fullName: formData.fullName.trim().length < 2 ? "Please enter your full name." : "",
      email: !EMAIL_PATTERN.test(formData.email.trim()) ? "Please enter a valid email address." : "",
      phoneNumber: !PHONE_PATTERN.test(formData.phoneNumber.trim()) ? "Please enter a valid phone number." : "",
      consent: !formData.consent ? "Please accept the privacy policy to continue." : "",
    }),
    [formData],
  );

  const isFormValid = !errors.fullName && !errors.email && !errors.phoneNumber && !errors.consent;

  const handleFieldChange = <K extends keyof FormState>(field: K, value: FormState[K]) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleBlur = (field: keyof TouchedState) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
  };

  const openCountryDropdown = () => {
    setIsInterestOpen(false);
    setIsCountryOpen((open) => !open);
  };

  const openInterestDropdown = () => {
    setIsCountryOpen(false);
    setIsInterestOpen((open) => !open);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setTouched({ fullName: true, email: true, phoneNumber: true, interest: true, consent: true });
    if (!isFormValid) return;
    setSubmitted(true);
  };

  if (!isOpen) return null;

  return (
    <div
      className="tte-overlay"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}>
      <div className="tte-dialog" role="dialog" aria-modal="true" aria-labelledby="tte-title" ref={dialogRef} tabIndex={-1}>
        <button type="button" className="tte-close" onClick={onClose} aria-label="Close talk to our expert form">
          <CloseIcon />
        </button>

        <div className="tte-card">
          <div className="tte-photo-panel">
            <div className="tte-photo-frame">
              <div className="tte-photo-inner">
                <video src="/videos/TalkToOurExpert.mp4" autoPlay muted loop playsInline className="tte-photo" aria-label="NeuroLXP learning expert wearing a headset, ready to help" />
                <button type="button" className="tte-play-button" onClick={() => onPlayClick?.()} aria-label="Play intro video">
                  <PlayIcon />
                </button>
              </div>
            </div>
          </div>

          <div className="tte-form-panel">
            <div className="tte-header">
              <h2 id="tte-title" className="tte-title">
                Talk to our Expert
              </h2>
              <p className="tte-subtitle">
                <BotIcon />
                <span>Get personalized learning guidance</span>
              </p>
            </div>

            <div className="tte-form-surface">
              {submitted ? (
                <div className="tte-success" role="status">
                  <p className="tte-success-title">Thanks, {formData.fullName.split(" ")[0]}!</p>
                  <p className="tte-success-body">Our expert has received your query and will reach out to you shortly.</p>
                </div>
              ) : (
                <form className="tte-form" onSubmit={handleSubmit} noValidate>
                  <div className="tte-field">
                    <label className="tte-label" htmlFor="tte-fullName">
                      Full Name
                    </label>
                    <div className={`tte-input-shell${touched.fullName && errors.fullName ? " tte-input-shell-error" : ""}`}>
                      <IconBubble>
                        <UserIcon />
                      </IconBubble>
                      <input id="tte-fullName" type="text" className="tte-input" placeholder="Enter your name" value={formData.fullName} onChange={(event) => handleFieldChange("fullName", event.target.value)} onBlur={() => handleBlur("fullName")} aria-invalid={touched.fullName && Boolean(errors.fullName)} aria-describedby={touched.fullName && errors.fullName ? "tte-fullName-error" : undefined} />
                    </div>
                    {touched.fullName && errors.fullName && (
                      <span id="tte-fullName-error" className="tte-error" role="alert">
                        {errors.fullName}
                      </span>
                    )}
                  </div>

                  <div className="tte-field">
                    <label className="tte-label" htmlFor="tte-email">
                      Email Address
                    </label>
                    <div className={`tte-input-shell${touched.email && errors.email ? " tte-input-shell-error" : ""}`}>
                      <IconBubble>
                        <MailIcon />
                      </IconBubble>
                      <input id="tte-email" type="email" className="tte-input" placeholder="Enter your email address" value={formData.email} onChange={(event) => handleFieldChange("email", event.target.value)} onBlur={() => handleBlur("email")} aria-invalid={touched.email && Boolean(errors.email)} aria-describedby={touched.email && errors.email ? "tte-email-error" : undefined} />
                    </div>
                    {touched.email && errors.email && (
                      <span id="tte-email-error" className="tte-error" role="alert">
                        {errors.email}
                      </span>
                    )}
                  </div>

                  <div className="tte-field">
                    <label className="tte-label" htmlFor="tte-phone">
                      Phone Number
                    </label>
                    <div className="tte-phone-row">
                      <div className="tte-country-select" ref={countryDropdownRef}>
                        <button type="button" className="tte-country-trigger" onClick={openCountryDropdown} aria-haspopup="listbox" aria-expanded={isCountryOpen}>
                          <span className="tte-country-flag" aria-hidden="true">
                            {getFlagEmoji(selectedCountry.iso2)}
                          </span>
                          <span className="tte-country-code">
                            {selectedCountry.iso2.toUpperCase()} (+{selectedCountry.dialCode})
                          </span>
                          <ArrowDownIcon open={isCountryOpen} />
                        </button>
                        {isCountryOpen && (
                          <div className="tte-country-panel" role="listbox">
                            <input type="text" className="tte-country-search" placeholder="Search country" value={countrySearch} onChange={(event) => setCountrySearch(event.target.value)} autoFocus />
                            <ul className="tte-country-list">
                              {filteredCountries.map((country) => (
                                <li key={country.iso2}>
                                  <button
                                    type="button"
                                    role="option"
                                    aria-selected={country.iso2 === formData.countryIso2}
                                    className={`tte-country-option${country.iso2 === formData.countryIso2 ? " tte-country-option-active" : ""}`}
                                    onClick={() => {
                                      handleFieldChange("countryIso2", country.iso2);
                                      setIsCountryOpen(false);
                                      setCountrySearch("");
                                    }}>
                                    <span className="tte-country-flag" aria-hidden="true">
                                      {getFlagEmoji(country.iso2)}
                                    </span>
                                    <span className="tte-country-name">{country.name}</span>
                                    <span className="tte-country-dial">+{country.dialCode}</span>
                                  </button>
                                </li>
                              ))}
                              {filteredCountries.length === 0 && <li className="tte-country-empty">No countries match your search.</li>}
                            </ul>
                          </div>
                        )}
                      </div>
                      <div className={`tte-input-shell tte-input-shell-grow${touched.phoneNumber && errors.phoneNumber ? " tte-input-shell-error" : ""}`}>
                        <IconBubble>
                          <PhoneIcon />
                        </IconBubble>
                        <input id="tte-phone" type="tel" inputMode="numeric" className="tte-input" placeholder="XXXXXXXXX" value={formData.phoneNumber} onChange={(event) => handleFieldChange("phoneNumber", event.target.value.replace(/[^0-9]/g, ""))} onBlur={() => handleBlur("phoneNumber")} aria-invalid={touched.phoneNumber && Boolean(errors.phoneNumber)} aria-describedby={touched.phoneNumber && errors.phoneNumber ? "tte-phone-error" : undefined} />
                      </div>
                    </div>
                    {touched.phoneNumber && errors.phoneNumber && (
                      <span id="tte-phone-error" className="tte-error" role="alert">
                        {errors.phoneNumber}
                      </span>
                    )}
                  </div>

                  <div className="tte-field" ref={interestDropdownRef}>
                    <span className="tte-label" id="tte-interest-label">
                      Select your Interest
                    </span>
                    <button type="button" className="tte-input-shell tte-interest-trigger" onClick={openInterestDropdown} aria-haspopup="listbox" aria-expanded={isInterestOpen} aria-labelledby="tte-interest-label">
                      <IconBubble>
                        <ClipboardIcon />
                      </IconBubble>
                      <span className="tte-interest-value">{formData.interest}</span>
                      <ArrowDownIcon open={isInterestOpen} />
                    </button>
                    {isInterestOpen && (
                      <div className="tte-interest-panel" role="listbox">
                        {INTEREST_OPTIONS.map((option) => {
                          const checked = option === formData.interest;
                          return (
                            <button
                              type="button"
                              key={option}
                              role="option"
                              aria-selected={checked}
                              className="tte-interest-option"
                              onClick={() => {
                                handleFieldChange("interest", option);
                                setTouched((prev) => ({ ...prev, interest: true }));
                                setIsInterestOpen(false);
                              }}>
                              <span className="tte-radio-bubble">{checked ? <RadioCheckedIcon /> : <RadioEmptyIcon />}</span>
                              <span className={`tte-interest-option-label${checked ? " tte-interest-option-label-active" : ""}`}>{option}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  <div className="tte-field">
                    <label className="tte-label" htmlFor="tte-query">
                      Describe your query or question in detail
                    </label>
                    <div className="tte-textarea-shell">
                      <textarea id="tte-query" className="tte-textarea" placeholder="Write your detailed query here......" value={formData.query} onChange={(event) => handleFieldChange("query", event.target.value)} />
                      <span className="tte-resize-icon" aria-hidden="true">
                        <ResizeIcon />
                      </span>
                    </div>
                  </div>

                  <label className="tte-consent">
                    <input type="checkbox" className="tte-consent-checkbox" checked={formData.consent} onChange={(event) => handleFieldChange("consent", event.target.checked)} onBlur={() => handleBlur("consent")} aria-invalid={touched.consent && Boolean(errors.consent)} aria-describedby={touched.consent && errors.consent ? "tte-consent-error" : undefined} />
                    <span className="tte-consent-box" aria-hidden="true" />
                    <span className="tte-consent-text">
                      I agree to be contacted for the platform demo and accept the{" "}
                      <a href="/privacy-policy" className="tte-consent-link">
                        Privacy Policy
                      </a>{" "}
                      of <strong>Prgeeq Global Solutions Private Limited.</strong>
                    </span>
                  </label>
                  {touched.consent && errors.consent && (
                    <span id="tte-consent-error" className="tte-error" role="alert">
                      {errors.consent}
                    </span>
                  )}

                  <button type="submit" className="tte-submit" disabled={!isFormValid}>
                    Submit Query
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
