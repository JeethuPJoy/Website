import CodingChallenge from "@/components/CodingChallenge/page";
import "@/components/DigitalLiteracy/CodingChallenge.css";

export default function codingChallengePage() {
  return <CodingChallenge />;
}